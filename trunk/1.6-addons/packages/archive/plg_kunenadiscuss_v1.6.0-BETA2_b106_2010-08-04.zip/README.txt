/**
* @version $Id: README.txt 2147 2010-04-02 06:06:20Z mahagr $
* Kunena Component
* @package Kunena
* @Copyright (C) 2010 Kunena All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.kunena.com
**/

Kunena Discuss Plugin README

PLEASE READ THIS ENTIRE FILE BEFORE INSTALLING Kunena Discuss 1.6.0-BETA2!

INTRODUCTION
============

Kunena Discuss enables your site visitors to discuss your content articles in designated forum categories.

Requirements: Joomla 1.5, Kunena Forum 1.6

END OF README
=============
